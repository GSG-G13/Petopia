function App() {

  return (
    <>
      <h1>Petopia</h1>
    </>
  )
}

export default App
