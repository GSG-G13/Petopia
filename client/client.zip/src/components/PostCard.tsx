import { Card, Space } from 'antd';
import React from 'react';
import { Carousel } from 'antd';
import { Share, Heart, MessageText1 } from 'iconsax-react';
import '../styles/post-card.css'

const PostCard: React.FC = () => {
    return <Space direction="vertical" size={16}>
        <Card className='card'>
            <div className='post-header'>
                <div className='user-post-container'>
                    <img src="https://i.imgur.com/tnXvDwt.png" alt="userImage" style={{ borderRadius: 40 }} />
                    <div className='user-post-info'>
                        <a href="" className='username'>Haitham</a>
                        <h4 className='date'>13 min ago</h4>
                    </div>
                </div>
                <div className='label'>
                    <div className='top-label'></div>
                    <p className='label-content'>Adoption</p>
                    <div className='down-label'></div>
                </div>
            </div>
            <Carousel>
                <div>
                    <img src="https://i.imgur.com/FnQHnjc.png" alt="image" className='img' />
                </div>
                <div>
                    <img src="https://i.imgur.com/KcYHnFr.jpg" alt="image" className='img' />
                </div>
                <div>
                    <img src="https://i.imgur.com/v5xOSq2.jpg" alt="image" className='img' />
                </div>
                <div>
                    <img src="https://i.imgur.com/v2v02Ge.jpg" alt="image" className='img' />
                </div>
            </Carousel>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa fugit inventore, distinctio natus unde asperiores magni illum nobis accusamus magnam officia, ducimus eaque ut? Est repellat a exercitationem dignissimos fugit?</p>
            <div className='post-buttons'>
                <div className='item'>
                    <Heart className='icon' variant="Outline" />
                    <p>22.5K Like</p>
                </div>
                <div className='item'>
                    <MessageText1 className='icon' variant="Outline" />
                    <p>22.5K Comment</p>
                </div>
                <div className='item'>
                    <Share className='icon' variant="Outline" />
                    <p>Share</p>
                </div>
            </div>
        </Card>
    </Space >
}
export default PostCard